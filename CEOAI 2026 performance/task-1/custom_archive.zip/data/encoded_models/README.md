# 2: encoded models

Each `model_NN.pt` is a PyTorch `state_dict` with a 256-bit message planted in its weights. There are eight models and four distinct schemes, two models per scheme. A scheme picks a parameter tensor, a slice of its flattened weights, and a bit position, and writes the message into the least-significant bits there. See `decoder_grammar.md` for the exact read.

Recover each model's 256 bits and submit them as `datapointID = model * 256 + bit`, `answer` in {0, 1}.
