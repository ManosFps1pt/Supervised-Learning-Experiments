# Encoding schemes for subtask 2

The eight networks in `encoded_models/` each carry a 256-bit message, planted with a least-significant-bit scheme. A scheme is three choices.

- A parameter tensor, one of `conv1.weight`, `conv2.weight`, `fc.weight`.
- A start offset into that tensor, flattened in row-major order.
- A bit position `b`.

Message bit `i` lives in element `start + i` of the flattened parameter. To read it, scale the weight by `1e6`, round to the nearest integer, and take bit `b`.

```python
flat = state_dict[param].reshape(-1)
value = int(round(float(flat[start + i]) * 1e6))
bit_i = (value >> b) & 1
```

Four distinct schemes were used, two networks each. The networks differ only in their weights, so finding one scheme tells you nothing about another until you find it too.

You submit the recovered bits, not a decoder program. Each row is `subtaskID,datapointID,answer` with `datapointID = model * 256 + bit` and `answer` in {0, 1}.
